
print("""
Task#1: Print all even numbers in one set and odd numbers in another set. Condition: Don't use 2nd for loop and output can't be horizontal.

Task#2: Print tables side-by-side

Task#3. Search Internet for how to print without newline in Python. Ex: Print fibonacci number on one line rather than default output.

Task#4: Recognize if the given integer is a mobile number without using count variable.

Task#5: Program to pring combination of letters from two strings. Make changes to produce all the genuine combinations and it should work with other string with duplicates eliminated.

Task#6: Program to split string into smaller batches. Write the code to do the unique split.

Task#7: Program to calculate PF according to the given age. Condition: use only one return and ask the age until a valid age is given betwen 10 and 60. Once age is valid then only ask for Basic salary. 

Task#8: Print the quarter to which the month belongs to. Condition: Both - like (jan or january) and all months  should work.

Task#9: Program to write the given key and values in a dictionary by inversing them. i.e. key should becomes values and values should become keys.

Task#10: Print add, sub, mul, div using only one if and else statement.

Task#11: Print the number pattern as shown:
1
2 2
3 3 3
4 4 4 4
=========
1
2 2
3 3 3
4 4 4

Task#11: Program to check standard Password rules (minimum: 8 length, 1 small-letter, 1 capital-letter, 1 number, and 1 special-character)

Task#12: Program to print palindrome string :ex: madam: withou using slicing[::-1], or in-built reverse functions. Use only pure loops to compare original and reversed.

""")

