import pytest

import skilift as sk

@pytest.fixture
def line5():
    line = sk.Line(5)
    return line

@pytest.fixture
def line_n(request):
    size = request.node.get_marker('line_size').args[0]
    line = sk.Line(size)
    return line

@pytest.fixture
def quad_lift10():
    lift = sk.Lift(10, sk.Quad)
    return lift


@pytest.fixture
def take_num():
    return 1

@pytest.fixture
def BenchN(request):
    size_ = request.node.get_marker('bench_size').args[0]
    class BSize(sk._Bench):
        size = size_
    return BSize
